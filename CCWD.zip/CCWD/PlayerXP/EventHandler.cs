﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.EventSystem.Events;
using System.Collections.Generic;

namespace level
{
    class EventHandler : IEventHandlerPlayerHurt
    {
        private Plugin plugin;
        private Server server;


        public EventHandler(Plugin plugin)
        {
            this.plugin = plugin;
            this.server = plugin.Server;
        }

        public void OnPlayerHurt(PlayerHurtEvent ev)
        {
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.E11_STANDARD_RIFLE)
            {
                ev.Damage = plugin.GetConfigInt("de_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.COM15)
            {
                ev.Damage = plugin.GetConfigInt("dc_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.P90)
            {
                ev.Damage = plugin.GetConfigInt("dp_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.MP7)
            {
                ev.Damage = plugin.GetConfigInt("dm_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.LOGICER)
            {
                ev.Damage = plugin.GetConfigInt("dl_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.USP)
            {
                ev.Damage = plugin.GetConfigInt("du_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CLASSD && ev.DamageType == DamageType.FRAG)
            {
                ev.Damage = plugin.GetConfigInt("dg_d");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.E11_STANDARD_RIFLE)
            {
                ev.Damage = plugin.GetConfigInt("de_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.COM15)
            {
                ev.Damage = plugin.GetConfigInt("dc_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.P90)
            {
                ev.Damage = plugin.GetConfigInt("dp_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.MP7)
            {
                ev.Damage = plugin.GetConfigInt("dm_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.LOGICER)
            {
                ev.Damage = plugin.GetConfigInt("dl_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.USP)
            {
                ev.Damage = plugin.GetConfigInt("du_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCIENTIST && ev.DamageType == DamageType.FRAG)
            {
                ev.Damage = plugin.GetConfigInt("dg_s");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.E11_STANDARD_RIFLE)
            {
                ev.Damage = plugin.GetConfigInt("de_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.COM15)
            {
                ev.Damage = plugin.GetConfigInt("dc_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.P90)
            {
                ev.Damage = plugin.GetConfigInt("dp_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.MP7)
            {
                ev.Damage = plugin.GetConfigInt("dm_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.LOGICER)
            {
                ev.Damage = plugin.GetConfigInt("dl_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.USP)
            {
                ev.Damage = plugin.GetConfigInt("du_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.NINETAILFOX && ev.DamageType == DamageType.FRAG)
            {
                ev.Damage = plugin.GetConfigInt("dg_ntf");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.E11_STANDARD_RIFLE)
            {
                ev.Damage = plugin.GetConfigInt("de_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.COM15)
            {
                ev.Damage = plugin.GetConfigInt("dc_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.P90)
            {
                ev.Damage = plugin.GetConfigInt("dp_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.MP7)
            {
                ev.Damage = plugin.GetConfigInt("dm_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.LOGICER)
            {
                ev.Damage = plugin.GetConfigInt("dl_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.USP)
            {
                ev.Damage = plugin.GetConfigInt("du_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.CHAOS_INSURGENCY && ev.DamageType == DamageType.FRAG)
            {
                ev.Damage = plugin.GetConfigInt("dg_ci");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.E11_STANDARD_RIFLE)
            {
                ev.Damage = plugin.GetConfigInt("de_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.COM15)
            {
                ev.Damage = plugin.GetConfigInt("dc_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.P90)
            {
                ev.Damage = plugin.GetConfigInt("dp_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.MP7)
            {
                ev.Damage = plugin.GetConfigInt("dm_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.LOGICER)
            {
                ev.Damage = plugin.GetConfigInt("dl_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.USP)
            {
                ev.Damage = plugin.GetConfigInt("du_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.TUTORIAL && ev.DamageType == DamageType.FRAG)
            {
                ev.Damage = plugin.GetConfigInt("dg_tut");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCP && ev.DamageType == DamageType.SCP_049)
            {
                ev.Damage = plugin.GetConfigInt("d_049");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCP && ev.DamageType == DamageType.SCP_096)
            {
                ev.Damage = plugin.GetConfigInt("d_096");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCP && ev.DamageType == DamageType.SCP_106)
            {
                ev.Damage = plugin.GetConfigInt("d_106");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCP && ev.DamageType == DamageType.POCKET)
            {
                ev.Damage = plugin.GetConfigInt("d_106p");
            }
            if (ev.Attacker.TeamRole.Team == Smod2.API.Team.SCP && ev.DamageType == DamageType.SCP_173)
            {
                ev.Damage = plugin.GetConfigInt("d_173");
            }
        }
    }
}




