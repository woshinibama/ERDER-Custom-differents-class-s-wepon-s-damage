﻿using System;
using System.IO;
using Smod2;
using Smod2.Attributes;
using Smod2.API;
using System.Collections.Generic;

namespace level
{
	[PluginDetails(
	author = "erder",
	name = "Custom different class's different's wepon's damage",
	description = "The plugin can custom the damage",
	id = "erder.Custom Damage",
	version = "1.0",
	SmodMajor = 3,
	SmodMinor = 4,
	SmodRevision = 1
	)]
	public class PlayerXP : Plugin
	{
		public static Plugin plugin;

        public override void OnDisable()
        {
            this.Info("自定义伤害加载出错");
        }
		public override void OnEnable()
		{
			plugin = this;
            this.Info("自定义伤害加载完毕");
        }



        public override void Register()
		{
			AddEventHandlers(new EventHandler(this));
            this.AddConfig(new Smod2.Config.ConfigSetting("de_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dp_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dm_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dl_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("du_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dg_d", 1000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_d", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("de_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dp_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dm_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dl_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("du_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dg_s", 1000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_s", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("de_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dp_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dm_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dl_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("du_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dg_ntf", 1000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_ntf", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("de_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dp_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dm_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dl_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("du_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dg_ci", 1000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_ci", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("de_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dp_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dm_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dl_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("du_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dg_tut", 1000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("dc_tut", 20, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("d_049", 100000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("d_096", 500000, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("d_106", 49, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("d_106p", 1, true, ""));
            this.AddConfig(new Smod2.Config.ConfigSetting("d_173", 100000, true, ""));




        }
    }
}
