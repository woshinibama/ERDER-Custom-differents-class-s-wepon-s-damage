﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.EventSystem.Events;

namespace level
{
    class EventHandler :IEventHandlerSetNTFUnitName, IEventHandlerRoundEnd, IEventHandlerRoundRestart, IEventHandlerPlayerDropItem
    {
        private Plugin plugin;
        private Server server;
        private int s = 1;
        public EventHandler(Plugin plugin)
        {
            this.plugin = plugin;
            this.server = plugin.Server;
        }

        public void OnSetNTFUnitName(SetNTFUnitNameEvent ev)
        {
            if (s == 1)
            {
                ev.Unit = "EPLSILION-11";
            }
            if (s == 2)
            {
                ev.Unit = "OMEGA-7";
            }
            s++;
        }

        public void OnRoundEnd(RoundEndEvent ev)
        {
            s = 1;
        }

        public void OnRoundRestart(RoundRestartEvent ev)
        {
            s = 1;
        }

        public void OnPlayerDropItem(PlayerDropItemEvent ev)
        {
            if(ev.Item.ItemType == ItemType.CUP)
            {
                ev.Player.SetHealth(ev.Player.GetHealth() + 1);
            }
        }
    }
}
