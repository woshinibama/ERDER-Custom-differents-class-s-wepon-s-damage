﻿using System;
using System.IO;
using Smod2;
using Smod2.Attributes;
using Smod2.API;
using System.Collections.Generic;

namespace level
{
	[PluginDetails(
	author = "cushaw",
	name = "sb",
	description = "sb",
	id = "cushaw.sb",
	version = "1.0",
	SmodMajor = 3,
	SmodMinor = 4,
	SmodRevision = 1
	)]
	public class PlayerXP : Plugin
	{
		public static Plugin plugin;

        public override void OnDisable()
        {
            this.Info("sb加载出错");
        }
		public override void OnEnable()
		{
			plugin = this;
            this.Info("sb加载完毕");
        }

		public override void Register()
		{
			AddEventHandlers(new EventHandler(this));
        }
	}
}
